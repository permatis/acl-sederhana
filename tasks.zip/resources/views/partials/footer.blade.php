<footer class="main-footer">
	<strong>Copyright © {{\Carbon\Carbon::now()->year}} <a href="#">Simple Task Managements</a>.</strong> All rights
	reserved.
</footer>