<?php $__env->startSection('title-page', 'Tasks'); ?>

<?php $__env->startSection('content'); ?>
	<div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">List All Task</h3>
            <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
        </div>
        <div class="box-body">
			<table class="table no-margin" id="table">
				<thead>
					<tr>
						<th>Name</th>
						<th>Description</th>
						<th>Update At</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
				</tbody>
			</table>
        </div>
        <div class="box-footer clearfix">
        	<button class="btn btn-sm btn-default btn-flat pull-left" id="btn-new">Create Task</button>
        </div>
    </div>

	<?php echo $__env->make('tasks.save', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('tasks.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php $__env->startSection('script'); ?>
    <script type="text/javascript">
    	$(function() {
    		// define datatables
			$('#table').DataTable({
			 	'processing': true, 
			 	'serverSide': true,
			 	'ajax': {
			 		'url': 'http://tasks.dev/api/v1/ajax/tasks',
			 		'type': 'POST'
			 	},
		        columns: [
		            { data: 'name', name: 'name' },
		            { data: 'description', name: 'description' },
		            { data: 'updated_at', name: 'updated_at' },
		            { data: 'action', name: 'action', orderable: false, searchable: false}
		        ]
		    });
    	});
    </script>
    <?php $__env->appendSection(); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>