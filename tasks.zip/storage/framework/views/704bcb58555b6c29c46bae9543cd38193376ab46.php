<footer class="main-footer">
	<strong>Copyright © <?php echo e(\Carbon\Carbon::now()->year); ?> <a href="#">Simple Task Managements</a>.</strong> All rights
	reserved.
</footer>