<aside class="main-sidebar">
    <section class="sidebar">
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(asset('img/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p>Administrator</p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li <?php if(request()->segment(1) == 'dashboard'): ?> class="active" <?php endif; ?>>
                <a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i><span>Dashboard</span></a>
            </li>
            <li <?php if(request()->segment(1) == 'tasks'): ?> class="active" <?php endif; ?>>
                <a href="<?php echo e(url('tasks')); ?>"><i class="fa fa-calendar"></i><span>Tasks</span></a>
            </li>
            <li <?php if(request()->segment(1) == 'roles'): ?> class="active" <?php endif; ?>>
                <a href="<?php echo e(url('roles')); ?>"><i class="fa fa-sitemap"></i><span>Roles</span></a>
            </li>
            <li <?php if(request()->segment(1) == 'permissions'): ?> class="active" <?php endif; ?>>
                <a href="<?php echo e(url('permissions')); ?>"><i class="fa fa-random"></i><span>Permissions</span></a>
            </li>
            <li <?php if(request()->segment(1) == 'users'): ?> class="active" <?php endif; ?>>
                <a href="<?php echo e(url('users')); ?>"><i class="fa fa-group"></i><span>Users</span></a>
            </li>
        </ul>
    </section>
</aside>