<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="_token" content="<?php echo csrf_token(); ?>" />
    <title><?php if(request()->segment(1) != '/'): ?> <?php echo $__env->yieldContent('title-page'); ?> - <?php endif; ?> Simple Task Managements</title>
    <!-- <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:100,300,400,700" rel='stylesheet' type='text/css'> -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/crud.js')); ?>"></script>
</head>

<body class="skin-black sidebar-mini">
    <div class="wrapper">
        <?php echo $__env->make('partials.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrapper" style="min-height: 916px;">
            <section class="content-header">
                <h1 id="page-title"><?php echo $__env->yieldContent('title-page'); ?></h1>
                <ol class="breadcrumb">
                    <?php echo breadcrumb('Dashboard'); ?>

                </ol>
            </section>
            
            <section class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </div>

        <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    
    <?php if(session('success')): ?>
    <script type="text/javascript">
            var n = noty({
                text: '<?php echo e(session('success')); ?>',
                theme: 'relax',
                layout: 'bottomRight',
                type: 'success',
                timeout: 5000,
                animation: {
                    open: 'animated fadeIn',
                    close: 'animated fadeOut',
                    easing: 'swing',
                    speed: 500 
                }
            });
    </script>
    <?php endif; ?>
</body>
</html>
